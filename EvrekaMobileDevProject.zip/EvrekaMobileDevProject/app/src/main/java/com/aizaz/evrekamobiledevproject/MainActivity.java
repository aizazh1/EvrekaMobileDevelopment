package com.aizaz.evrekamobiledevproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.tvResult)
    TextView tvResult;
    @BindView(R.id.tvDate)
    TextView tvDate;
    @BindView(R.id.button)
    Button button;

    Handler timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        timer=new Handler();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getApi();
            }
        });

        timer.postDelayed(new Runnable() {
            @Override
            public void run() {
                getApi();
                timer.postDelayed(this,2000);
            }
        },0);
    }

    public void getApi(){
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("http://data.fixer.io/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        final JsonGet jsonGet=retrofit.create(JsonGet.class);
        String time=new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(new Date());
        tvDate.setText(time);
        Call<Currency> currencyCall=jsonGet.getCurrency();
        currencyCall.enqueue(new Callback<Currency>() {
            @Override
            public void onResponse(Call<Currency> call, Response<Currency> response) {
                if(!response.isSuccessful()){
                    tvResult.setText("Code: "+response.code());
                    return;
                }
                Currency currency=response.body();

                tvResult.setText("AED: "+currency.getRates().getAED()+"\n\nAFN: "+currency.getRates().getAFN()
                        +"\n\nALL: "+currency.getRates().getALL());
            }

            @Override
            public void onFailure(Call<Currency> call, Throwable t) {
                tvResult.setText(t.getMessage());
            }
        });
    }
}

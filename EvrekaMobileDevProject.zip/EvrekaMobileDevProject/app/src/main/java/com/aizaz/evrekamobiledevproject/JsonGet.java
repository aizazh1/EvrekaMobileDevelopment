package com.aizaz.evrekamobiledevproject;

import retrofit2.Call;
import retrofit2.http.GET;

public interface JsonGet {
    @GET("api/latest?access_key=0f686a82aeffe8c98a679ed1fc905f87&format=1")
    Call<Currency> getCurrency();
}

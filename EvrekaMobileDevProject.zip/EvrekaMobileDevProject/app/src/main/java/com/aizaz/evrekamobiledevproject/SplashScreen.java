package com.aizaz.evrekamobiledevproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SplashScreen extends AppCompatActivity {

    Handler handler;
    private final int SPLASH_TIMEOUT=2000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        handler=new Handler();


        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Retrofit retrofit=new Retrofit.Builder()
                        .baseUrl("http://data.fixer.io/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
                final JsonGet jsonGet=retrofit.create(JsonGet.class);
                Call<Currency> currencyCall=jsonGet.getCurrency();
                currencyCall.enqueue(new Callback<Currency>() {
                    @Override
                    public void onResponse(Call<Currency> call, Response<Currency> response) {
                        if(!response.isSuccessful()){
                            displayToast();
                            finish();
                        }
                        Intent intent=new Intent(SplashScreen.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    }

                    @Override
                    public void onFailure(Call<Currency> call, Throwable t) {
                        displayToast();
                        finish();
                    }
                });
            }
        },SPLASH_TIMEOUT);
    }

    private void displayToast(){
        Toast.makeText(SplashScreen.this,"API cannot be reached",Toast.LENGTH_LONG).show();
    }
}

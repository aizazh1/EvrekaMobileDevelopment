package com.aizaz.evrekamobiledevproject;

public class Rates {
    private double AED,AFN,ALL;

    public double getAED() {
        return AED;
    }

    public double getAFN() {
        return AFN;
    }

    public double getALL() {
        return ALL;
    }
}

package com.aizaz.evrekamobiledevproject;

public class Currency {
    private Rates rates;

    public Rates getRates() {
        return rates;
    }
}
